#include <iostream>
#include "hangman.h"

using namespace std;

int main(){
    Hangman hang;
    
    hang.startGame();
}