#CS 202 FINAL LAB

Authors: Ahmed Ghazi, Chris Ramos, Kevin Canas
Condensed instructions/Quick Start:
To use this program, you need to type these commands into the command line in this order: "make clean", then "make", and then "./hangman".
After you compile and run the program, there will be in game prompts and options that you can follow to play the game.

Longer description:
This repo contains the C++ code to our group project: Hangman. 
A brief overview of our game's features:

-Difficulties: there are 3 difficulties Easy(7 lives), Medium(6 lives), and Hard(5 lives)

-Hints: You get 1 hint, regardless of difficulty, that reveals the first letter available that hasn't been guessed. The downside of using a hint is that it takes away 1 life.

-Printing hangman: The hangman will be printed differently depending on how many lives you have.

The data types we use in this code are sets, vectors, strings, ints, booleans, and chars
